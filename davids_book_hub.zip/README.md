# David's Book Hub — Static Site (Default)

This is a ready-to-deploy static website (HTML/CSS/JS) created for **David Otieno**.
It includes:
- `index.html` — home page with search, categories, trending, and book cards.
- `summaries.html` — full book summaries pages.
- `about.html`, `contact.html`, `privacy.html` — basic supporting pages.
- `styles.css` and `script.js` — site styles and client-side interactivity.
- `ads.txt` — placeholder for AdSense publisher ID.
- `README.md` — this file with deployment instructions.

## How to preview locally
1. Unzip the files.
2. Open `index.html` in your web browser. For full functionality (relative paths), it's fine to open from the file system.

## How to deploy (GitHub Pages)
1. Create a GitHub repository (public or private).
2. Upload the files to the repository (you can drag and drop in GitHub web UI).
3. In the repo Settings -> Pages, set the source to the `main` branch and `/ (root)` folder. Save.
4. Your site will be available at `https://<your-username>.github.io/<repo-name>/` in a few minutes.

## How to add Google AdSense
1. Apply and be approved at https://www.google.com/adsense/.
2. Add the AdSense script in the `<head>` of `index.html` and other pages where you want ads.
3. Replace the placeholder `ads.txt` publisher ID with your actual AdSense publisher ID.

## Notes & Legal
- Do NOT upload full copyrighted books without permission. Use summaries, public domain works, or obtain licenses.
- To make the Trending section dynamic using APIs (Google Books), you'll need an API key and optional serverless functions (Netlify) to keep the key private.

---
If you want, I can also:
- Create a GitHub repo for you and push these files (you'll need to give me write access or create the repo and invite me).
- Generate a ZIP file ready to download and upload — tell me and I'll provide the link.
