// script.js — client-side search and filtering for the static site

function searchBooks(){
  const q = document.getElementById('searchInput').value.trim().toLowerCase();
  const cards = document.querySelectorAll('.book-card');
  cards.forEach(card => {
    const title = card.querySelector('h4').innerText.toLowerCase();
    const excerpt = card.querySelector('.excerpt').innerText.toLowerCase();
    if(q === '' || title.includes(q) || excerpt.includes(q)){
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

function filterCategory(){
  const cat = document.getElementById('categoryFilter').value;
  const cards = document.querySelectorAll('.book-card');
  cards.forEach(card => {
    if(cat === 'all' || card.dataset.category === cat){
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

// Optional: allow clicking trending item to search
document.addEventListener('click', function(e){
  if(e.target.classList.contains('trending-item')){
    const text = e.target.textContent.split('—')[0].trim();
    document.getElementById('searchInput').value = text;
    searchBooks();
    window.scrollTo({top: 200, behavior: 'smooth'});
  }
});
