// config.js — place your Google Books API key below if you want dynamic lookups.
// To get a key: https://console.cloud.google.com/apis/credentials
// After adding your key, you can call fetchBooks(q) from dark-script.js
const GOOGLE_BOOKS_API_KEY = ""; // <-- paste your key between the quotes
