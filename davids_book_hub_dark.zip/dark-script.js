
// dark-script.js — search, filter, trending click, and Google Books API helper (key in config.js)
function searchBooks(){
  const q = document.getElementById('searchInput').value.trim().toLowerCase();
  const cards = document.querySelectorAll('.card');
  cards.forEach(card => {
    const title = card.querySelector('h3').innerText.toLowerCase();
    const excerpt = (card.querySelector('.excerpt') || {innerText:''}).innerText.toLowerCase();
    if(!q || title.includes(q) || excerpt.includes(q)){
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

function filterCategory(){
  const cat = document.getElementById('categoryFilter').value;
  const cards = document.querySelectorAll('.card');
  cards.forEach(card => {
    if(cat === 'all' || card.dataset.category === cat){
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

// Trending chips click behaviour
document.addEventListener('click', function(e){
  if(e.target.classList.contains('chip')){
    const title = e.target.dataset.title;
    document.getElementById('searchInput').value = title;
    searchBooks();
    window.scrollTo({top:200, behavior:'smooth'});
  }
});

// Google Books helper (optional). Put API key into config.js as GOOGLE_BOOKS_API_KEY.
// Example usage (client-side): fetchBooks('harry potter');
async function fetchBooks(q){
  try{
    if(typeof GOOGLE_BOOKS_API_KEY === 'undefined' || !GOOGLE_BOOKS_API_KEY){
      console.warn('No Google Books API key set. See config.js');
      return null;
    }
    const url = `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(q)}&key=${GOOGLE_BOOKS_API_KEY}&maxResults=6`;
    const res = await fetch(url);
    const data = await res.json();
    return data;
  }catch(err){
    console.error('Books fetch error', err);
    return null;
  }
}
