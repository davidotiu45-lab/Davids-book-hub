
# David's Book Hub — Dark Theme (Upgraded)

Files included:
- index.html, summaries.html, about.html, contact.html, privacy.html
- dark-styles.css, dark-script.js, config.js
- assets/logo.svg (simple icon-style logo)
- ads.txt (placeholder), README.md (this file)

## How to replace your current GitHub Pages site with this upgraded version
1. Download and extract this ZIP.
2. Open your repository on GitHub (https://github.com/your-username/davids-book-hub).
3. Click "Add file" → "Upload files".
4. Drag-and-drop the contents of the extracted folder (all files and the assets folder), and commit changes.
5. Wait a couple of minutes and visit: https://your-username.github.io/davids-book-hub/

## Adding Google Books API Key (optional)
1. Go to Google Cloud Console → APIs & Services → Credentials → Create API key.
2. Edit config.js and paste your key into GOOGLE_BOOKS_API_KEY variable (between the quotes).
3. Commit config.js to your repo. The client-side script has a helper function `fetchBooks(q)` you can call manually or wire to a search UI.

## Adding AdSense
1. Apply for Google AdSense and get approved.
2. Paste the AdSense `<script>` provided by Google into the head of index.html where the placeholder comment `<!-- ADSENSE_HEAD_PLACEHOLDER -->` is.
3. Replace the ad-slot placeholder divs in HTML (top-ad, side-ad, footer-ad) with the ad unit code Google gives you.
4. Update ads.txt with your publisher ID (replace pub-000... in ads.txt).

## Notes
- Do not upload full copyrighted books. Use summaries, public domain text, or obtain permission/license.
- If you want me to deploy the files directly to your GitHub repo, give me the repo link and invite me as collaborator, or simply upload the ZIP yourself following steps above.
